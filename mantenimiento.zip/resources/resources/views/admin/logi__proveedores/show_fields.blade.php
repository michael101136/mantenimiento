<!-- Id Field -->
<div class="form-group">
    {!! Form::label('id', 'Id:') !!}
    <p>{!! $logiProveedores->id !!}</p>
</div>

<!-- Razonsoc Field -->
<div class="form-group">
    {!! Form::label('razonsoc', 'Razonsoc:') !!}
    <p>{!! $logiProveedores->razonsoc !!}</p>
</div>

<!-- Ruc Field -->
<div class="form-group">
    {!! Form::label('ruc', 'Ruc:') !!}
    <p>{!! $logiProveedores->ruc !!}</p>
</div>

<!-- User Create Field -->
<div class="form-group">
    {!! Form::label('user_create', 'User Create:') !!}
    <p>{!! $logiProveedores->user_create !!}</p>
</div>

<!-- Web Field -->
<div class="form-group">
    {!! Form::label('web', 'Web:') !!}
    <p>{!! $logiProveedores->web !!}</p>
</div>

<!-- Estado Field -->
<div class="form-group">
    {!! Form::label('estado', 'Estado:') !!}
    <p>{!! $logiProveedores->estado !!}</p>
</div>

<!-- Created At Field -->
<div class="form-group">
    {!! Form::label('created_at', 'Created At:') !!}
    <p>{!! $logiProveedores->created_at !!}</p>
</div>

<!-- Updated At Field -->
<div class="form-group">
    {!! Form::label('updated_at', 'Updated At:') !!}
    <p>{!! $logiProveedores->updated_at !!}</p>
</div>

