
@extends('admin.layout.master')

@section('content')

 <div class="right_col" role="main">
 <section class="content-header">

    </section>
          <div class="">

            <div class="row">
              <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="x_panel">
                  <div class="x_title">
                  @include('flash::message')
                    <ul class="nav navbar-right panel_toolbox">
                      <li><a class="collapse-link"><i class="fa fa-chevron-up"></i></a>
                      </li>
                      <li class="dropdown">
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false"><i class="fa fa-wrench"></i></a>
                        <ul class="dropdown-menu" role="menu">
                          <li><a href="#">Settings 1</a>
                          </li>
                          <li><a href="#">Settings 2</a>
                          </li>
                        </ul>
                      </li>
                      <li><a class="close-link"><i class="fa fa-close"></i></a>
                      </li>
                    </ul>
                    <div class="clearfix"></div>

                  </div>
                  <h1 class="pull-left"> <a class="btn btn-primary pull-right" style="margin-top: -10px;margin-bottom: 5px" href="{!! route('usuarios.create') !!}">Crear</a></h1>
                  <div class="x_content">


                  @include('admin.usuarios.table')

                <!--  <div class="container">-->
                <!--      <h2>Laravel DataTable - Tuts Make</h2>-->
                <!--    <table class="table table-bordered" id="laravel_datatable">-->
                <!--      <thead>-->
                <!--          <tr>-->
                <!--            <th>Id</th>-->
                <!--            <th>Name</th>-->
                <!--            <th>Email</th>-->
                <!--            <th>Created at</th>-->
                <!--          </tr>-->
                <!--      </thead>-->
                <!--    </table>-->
                <!--</div>-->

                  </div>
                </div>
              </div>



            </div>
          </div>
        </div>

@endsection


@section('script')
<script>
$(document).ready(function() {
  $('#inicio').DataTable({
    "language": {
      "url": "/admin/idioma/Spanish.json"
    }
  });

  $('#laravel_datatable').DataTable({

            "language": {
              "url": "/admin/idioma/Spanish.json"
            },
           processing: true,
           serverSide: true,
           ajax: "{{ url('users-list') }}",
           columns: [
                    { data: 'id', name: 'id' },
                    { data: 'name', name: 'name' },
                    { data: 'email', name: 'email' },
                    { data: 'created_at', name: 'created_at' }
                 ]
        });

});
</script>


@endsection


